document.addEventListener('DOMContentLoaded', function() {
    const converterForm = document.getElementById('currencyConverter');
    const sourceCurrency = document.getElementById('sourceCurrency');
    const destinationCurrency = document.getElementById('destinationCurrency');
    const amountInput = document.getElementById('amount');
    const conversionRate = document.getElementById('conversionRate');
    const calculationDetails = document.getElementById('calculationDetails');
    const dateTime = document.getElementById('dateTime');
    const errorMessage = document.getElementById('errorMessage');

    const fetchData = async () => {
        try {
            const response = await fetch('https://www.floatrates.com/daily/eur.json');
            return await response.json();
        } catch (error) {
            console.error('Error fetching data:', error);
        }
    };

    const populateCurrencies = async () => {
        const data = await fetchData();
        if (data) {
            for (const currencyCode in data) {
                const option = document.createElement('option');
                option.value = currencyCode;
                option.textContent = currencyCode.toUpperCase();
                sourceCurrency.appendChild(option.cloneNode(true));
                destinationCurrency.appendChild(option);
            }
        }
    };

    const convertCurrency = async (event) => {
        event.preventDefault();

        const sourceValue = sourceCurrency.value.toUpperCase();
        const destValue = destinationCurrency.value.toUpperCase();
        const amount = parseFloat(amountInput.value);
        const data = await fetchData();

        if (amount <= 0) {
            errorMessage.textContent = 'Amount must be greater than zero.';
            return;
        }

        const rate = data[destValue.toLowerCase()].rate;
        const result = amount * rate;

        // Get current timestamp in GMT and format it in UK style (DD/MM/YYYY HH:MM)
        const now = new Date();
        const timestamp = now.toGMTString();

        conversionRate.textContent = `Conversion Rate: 1 ${sourceValue} = ${rate.toFixed(4)} ${destValue}`;
        calculationDetails.innerHTML = `<b>Calculation:</b> ${amount.toFixed(2)} ${sourceValue} in ${destValue}=${result.toFixed(2)}  ${destValue}`;
        dateTime.innerHTML = `<b>Date and Time:</b> ${timestamp}`;
    };

    populateCurrencies();
    converterForm.addEventListener('submit', convertCurrency);
});
